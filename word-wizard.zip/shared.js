(() => {
  const TARGET_LANGUAGES = [
    { code: "es", label: "Spanish" },
    { code: "fr", label: "French" },
    { code: "de", label: "German" },
    { code: "it", label: "Italian" },
    { code: "pt", label: "Portuguese" },
    { code: "ja", label: "Japanese" },
    { code: "ko", label: "Korean" },
    { code: "zh", label: "Chinese (Simplified)" },
    { code: "zh-Hant", label: "Chinese (Traditional)" },
    { code: "nl", label: "Dutch" },
    { code: "pl", label: "Polish" },
    { code: "ru", label: "Russian" },
    { code: "tr", label: "Turkish" },
    { code: "ar", label: "Arabic" },
    { code: "hi", label: "Hindi" },
    { code: "th", label: "Thai" },
    { code: "vi", label: "Vietnamese" },
    { code: "id", label: "Indonesian" },
    { code: "sv", label: "Swedish" },
    { code: "da", label: "Danish" },
    { code: "fi", label: "Finnish" },
    { code: "no", label: "Norwegian" },
    { code: "cs", label: "Czech" },
    { code: "el", label: "Greek" },
    { code: "he", label: "Hebrew" },
    { code: "hu", label: "Hungarian" },
    { code: "ro", label: "Romanian" },
    { code: "uk", label: "Ukrainian" },
    { code: "bg", label: "Bulgarian" },
    { code: "bn", label: "Bengali" },
    { code: "hr", label: "Croatian" },
    { code: "sk", label: "Slovak" },
    { code: "sl", label: "Slovenian" },
  ];

  const FREQUENCY_MODES = [
    {
      id: "rare",
      label: "Rare",
      hint: "A light sprinkle — about 1 in 12 words",
    },
    {
      id: "often",
      label: "Often",
      hint: "Steady practice — about 1 in 4 words",
    },
    {
      id: "sentences",
      label: "Full sentences",
      hint: "Every few sentences swapped entirely",
    },
  ];

  const COLOR_THEMES = [
    { id: "yellow", label: "Yellow" },
    { id: "blue", label: "Blue" },
    { id: "green", label: "Green" },
    { id: "orange", label: "Orange" },
    { id: "pink", label: "Pink" },
    { id: "gray", label: "Gray" },
  ];

  const DEFAULT_SETTINGS = {
    enabled: true,
    frequency: "often",
    targetLanguage: "es",
    // chrome = on-device packs (fast). online is opt-in and slower.
    engine: "chrome",
    colorTheme: "yellow",
    chromePackReady: false,
  };

  /** Hosts / patterns where Word Wizard must never rewrite text (search engines). */
  const SEARCH_ENGINE_HOST_RE =
    /(^|\.)((google)\.[a-z.]+|(bing|duckduckgo|ecosia|startpage|baidu|yandex|qwant|ask|aol|dogpile|wolframalpha|you|kagi|perplexity|naver|daum|sogou|gigablast|swisscows|searx|brave)\.[a-z.]+)$/i;

  const SEARCH_ENGINE_HOSTS = new Set(
    [
      "google.com",
      "bing.com",
      "duckduckgo.com",
      "duck.com",
      "search.yahoo.com",
      "yahoo.com",
      "search.brave.com",
      "ecosia.org",
      "startpage.com",
      "baidu.com",
      "yandex.com",
      "yandex.ru",
      "yandex.by",
      "yandex.kz",
      "yandex.uz",
      "ask.com",
      "aol.com",
      "search.aol.com",
      "dogpile.com",
      "wolframalpha.com",
      "qwant.com",
      "swisscows.com",
      "you.com",
      "kagi.com",
      "perplexity.ai",
      "naver.com",
      "search.naver.com",
      "daum.net",
      "search.daum.net",
      "sogou.com",
      "so.com",
      "360.cn",
      "gigablast.com",
      "metacrawler.com",
      "webcrawler.com",
      "excite.com",
      "lycos.com",
      "info.com",
      "zapmeta.com",
      "searchencrypt.com",
      "gibiru.com",
      "mojeek.com",
      "lukol.com",
      "oscobo.com",
      "yep.com",
      "phind.com",
      "komo.ai",
      "andisearch.com",
      "searchgpt.com",
      "chatgpt.com",
    ].map((h) => h.toLowerCase())
  );

  function hostMatchesSearchEngine(hostname) {
    const host = String(hostname || "")
      .toLowerCase()
      .replace(/^www\./, "");
    if (!host) return false;
    if (SEARCH_ENGINE_HOSTS.has(host)) return true;
    if (host.startsWith("search.")) return true;
    if (host.includes("google.")) return true;
    if (host.includes("yandex.")) return true;
    if (host.includes("duckduckgo.")) return true;
    if (SEARCH_ENGINE_HOST_RE.test(host)) return true;
    // Yahoo search surfaces
    if (host.endsWith("yahoo.com") || host.includes("search.yahoo.")) return true;
    return false;
  }

  function isSearchEngineLocation(loc = globalThis.location) {
    try {
      return hostMatchesSearchEngine(loc.hostname);
    } catch {
      return false;
    }
  }

  const SKIP_WORDS = new Set(
    "a an the and or but if as at by for from in into of on onto to with without within is are was were be been being am do does did done have has had having will would can could should may might must shall not no nor so yet both either neither each every all any some such than then that this these those it its itself he she they them their we us our you your i me my what which who whom whose when where why how".split(
      " "
    )
  );

  const INSTALL_TIMEOUT_MS = 300000;

  /** Edge/Chrome sometimes prefer a regional tag over the short code. */
  const LANGUAGE_CODE_ALIASES = {
    zh: ["zh", "zh-Hans", "zh-CN"],
    "zh-Hant": ["zh-Hant", "zh-TW", "zh-HK"],
    pt: ["pt", "pt-BR", "pt-PT"],
    no: ["nb", "no", "nn"],
    he: ["he", "iw"],
    id: ["id", "in"],
  };

  function languageCandidates(targetLanguage) {
    const code = String(targetLanguage || "").trim();
    const aliases = LANGUAGE_CODE_ALIASES[code] || [code];
    return [...new Set(aliases.filter(Boolean))];
  }

  /** Map Chrome BCP-47 tags to Google gtx codes when they differ. */
  const GTX_LANG = {
    "zh-Hant": "zh-TW",
    zh: "zh-CN",
    he: "iw",
  };

  function hashString(value) {
    let hash = 2166136261;
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function shouldPick(token, index, rate) {
    const bucket = hashString(`${token.toLowerCase()}::${index}`) % 1000;
    return bucket < rate * 1000;
  }

  async function getSettings() {
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.sync) {
        resolve({ ...DEFAULT_SETTINGS });
        return;
      }
      chrome.storage.sync.get(DEFAULT_SETTINGS, (result) => {
        resolve({ ...DEFAULT_SETTINGS, ...result });
      });
    });
  }

  async function saveSettings(partial) {
    const next = { ...(await getSettings()), ...partial };
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.sync) {
        resolve(next);
        return;
      }
      chrome.storage.sync.set(next, () => resolve(next));
    });
  }

  function translatorSupported() {
    return typeof globalThis.Translator !== "undefined";
  }

  /** Detect Chrome vs Edge for setup copy and internals links. */
  function getBrowserInfo() {
    const ua = String(globalThis.navigator?.userAgent || "");
    const isEdge = /\bEdg\//.test(ua);
    const isChrome = /\bChrome\//.test(ua) && !isEdge && !/\bOPR\//.test(ua);
    const match = ua.match(/\b(?:Edg|Chrome)\/(\d+)/);
    const version = match ? Number(match[1]) : 0;
    const name = isEdge ? "Edge" : isChrome ? "Chrome" : "Chromium";
    const minVersion = isEdge ? 148 : 138;
    const scheme = isEdge ? "edge" : "chrome";
    return {
      isEdge,
      isChrome,
      name,
      version,
      minVersion,
      supportedVersion: version >= minVersion,
      // Language pack manager (Chrome + Edge)
      translationInternalsUrl: `${scheme}://on-device-translation-internals/`,
      // Broader on-device AI / model status
      onDeviceInternalsUrl: `${scheme}://on-device-internals/`,
      // TranslateKit / EdgeLLMRuntime component status
      componentsUrl: `${scheme}://components/`,
      languagesSettingsUrl: isEdge
        ? "edge://settings/languages"
        : "chrome://settings/languages",
      label: isEdge
        ? "Microsoft Edge (desktop 148+)"
        : "Google Chrome (desktop 138+)",
    };
  }

  function hasUserActivation() {
    try {
      return Boolean(navigator.userActivation?.isActive);
    } catch {
      return false;
    }
  }

  function pairOptions(targetLanguage) {
    return {
      sourceLanguage: "en",
      targetLanguage,
    };
  }

  async function checkPairAvailability(targetLanguage) {
    if (!translatorSupported()) {
      return "unsupported";
    }
    const rank = {
      available: 4,
      downloading: 3,
      downloadable: 2,
      unavailable: 1,
      unsupported: 0,
    };
    let best = "unavailable";
    for (const code of languageCandidates(targetLanguage)) {
      try {
        const status = await Translator.availability(pairOptions(code));
        if ((rank[status] || 0) > (rank[best] || 0)) {
          best = status;
        }
        if (status === "available") return "available";
      } catch {
        // try next alias
      }
    }
    return best;
  }

  function withTimeout(promise, ms, message) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => {
        const err = new Error(message);
        err.code = "timeout";
        reject(err);
      }, ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  function progressPercent(event) {
    const loaded = Number(event?.loaded);
    const total = Number(event?.total);
    if (Number.isFinite(loaded) && Number.isFinite(total) && total > 0) {
      return Math.min(100, Math.round((loaded / total) * 100));
    }
    if (Number.isFinite(loaded)) {
      return loaded <= 1 ? Math.round(loaded * 100) : Math.min(100, Math.round(loaded));
    }
    return 0;
  }

  function normalizeChromeError(error) {
    const message = String(error?.message || error || "");
    if (error?.code === "timeout" || /timed out/i.test(message)) {
      const err = new Error(message);
      err.code = "timeout";
      err.cause = error?.cause || error;
      return err;
    }
    if (error?.name === "NotAllowedError" || /user gesture|user activation/i.test(message)) {
      const err = new Error(
        "Your browser needs a direct click to download this language pack"
      );
      err.code = "needs-gesture";
      err.cause = error;
      return err;
    }
    if (
      error?.name === "NotSupportedError" ||
      /Unable to create translator|language pair|not supported|translation service crashed/i.test(
        message
      )
    ) {
      const err = new Error(
        "On-device translator could not be created for this language yet"
      );
      err.code = "not-supported";
      err.cause = error;
      return err;
    }
    const err = error instanceof Error ? error : new Error(message);
    return err;
  }

  const translatorCache = new Map();

  function attachDownloadMonitor(monitor, onProgress) {
    try {
      monitor.addEventListener("downloadprogress", (event) => {
        onProgress?.(progressPercent(event), event);
      });
    } catch {
      // Some Edge builds expose a monitor without addEventListener.
    }
  }

  /** Fire Translator.create synchronously; try with monitor, then without. */
  function createTranslatorSession(options, onProgress) {
    try {
      return Translator.create({
        ...options,
        monitor(m) {
          attachDownloadMonitor(m, onProgress);
        },
      });
    } catch (withMonitorError) {
      try {
        return Translator.create(options);
      } catch (plainError) {
        return Promise.reject(plainError || withMonitorError);
      }
    }
  }

  async function finishTranslatorSession(translator, preferredCode) {
    if (translator?.ready) {
      try {
        await withTimeout(
          translator.ready,
          INSTALL_TIMEOUT_MS,
          "Language pack download timed out while finishing setup."
        );
      } catch (error) {
        // Edge sometimes never exposes a resolving ready promise after create().
        if (error?.code !== "timeout") throw error;
      }
    }

    // Smoke test is best-effort — create() succeeding is enough to mark the pack ready.
    let sample = "";
    try {
      sample = await withTimeout(
        translator.translate("hello"),
        30000,
        "On-device pack installed, but the first test translation timed out."
      );
    } catch {
      sample = "";
    }

    translatorCache.set(preferredCode, translator);
    return { translator, sample, code: preferredCode };
  }

  /**
   * Start Translator.create() immediately from a click (no awaits before this).
   * On Edge, retries regional language tags and a no-monitor create if needed.
   */
  function startTranslatorCreate(targetLanguage, onProgress) {
    if (!translatorSupported()) {
      const err = new Error("Translator API not supported");
      err.code = "unsupported";
      return Promise.reject(err);
    }

    const cached = translatorCache.get(targetLanguage);
    if (cached) {
      return Promise.resolve({
        translator: cached,
        sample: "",
        code: targetLanguage,
      });
    }

    const candidates = languageCandidates(targetLanguage);
    const primary = candidates[0];
    const attempts = [];

    // Must call create() synchronously inside the user gesture.
    let firstPromise;
    try {
      firstPromise = createTranslatorSession(pairOptions(primary), onProgress);
    } catch (error) {
      return Promise.reject(normalizeChromeError(error));
    }
    attempts.push({ code: primary, promise: firstPromise });

    return withTimeout(
      (async () => {
        let lastError;
        for (let i = 0; i < candidates.length; i += 1) {
          const code = candidates[i];
          let createPromise = attempts[i]?.promise;
          if (!createPromise) {
            // Later aliases: gesture may be gone, but NotSupported retries don't need it.
            try {
              createPromise = createTranslatorSession(pairOptions(code), onProgress);
            } catch (error) {
              lastError = error;
              continue;
            }
          }

          try {
            const translator = await createPromise;
            return finishTranslatorSession(translator, targetLanguage);
          } catch (error) {
            lastError = error;
            // If monitor path failed, retry the same code without monitor once.
            if (i === 0) {
              try {
                const plain = await Translator.create(pairOptions(code));
                return finishTranslatorSession(plain, targetLanguage);
              } catch (plainError) {
                lastError = plainError;
              }
            }
          }
        }
        throw normalizeChromeError(lastError || new Error("Translator.create failed"));
      })(),
      INSTALL_TIMEOUT_MS,
      "Language pack download timed out. Open the language pack manager, install en + your language, restart the browser, then retry."
    );
  }

  async function getTranslator(targetLanguage, onProgress) {
    const cached = translatorCache.get(targetLanguage);
    if (cached) return cached;

    if (!translatorSupported()) {
      const err = new Error("Translator API not supported");
      err.code = "unsupported";
      throw err;
    }

    const availability = await checkPairAvailability(targetLanguage);
    if (availability === "unavailable" || availability === "unsupported") {
      const err = new Error("Language pair unavailable on this device");
      err.code = "unavailable";
      throw err;
    }

    if (
      (availability === "downloadable" || availability === "downloading") &&
      !hasUserActivation()
    ) {
      const err = new Error(
        "Your browser needs a click to download this language pack"
      );
      err.code = "needs-gesture";
      throw err;
    }

    const result = await startTranslatorCreate(targetLanguage, onProgress);
    return result?.translator || result;
  }

  function toGtxLanguage(code) {
    return GTX_LANG[code] || code;
  }

  let chromeUnusable = false;
  const memoryCache = new Map();
  let diskCacheLoaded = false;
  let diskCacheDirty = false;
  let diskCacheTimer = null;
  let googleCooldownUntil = 0;
  let requestChain = Promise.resolve();
  let lastNetworkAt = 0;
  const MIN_NETWORK_GAP_MS = 550;

  function cacheKey(targetLanguage, text) {
    return `${targetLanguage}::${text}`;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function isServiceWorker() {
    return typeof ServiceWorkerGlobalScope !== "undefined" &&
      globalThis instanceof ServiceWorkerGlobalScope;
  }

  async function ensureDiskCache() {
    if (diskCacheLoaded || !globalThis.chrome?.storage?.local) {
      diskCacheLoaded = true;
      return;
    }
    diskCacheLoaded = true;
    try {
      const stored = await chrome.storage.local.get(["wwCache", "wwGoogleCooldown"]);
      const cache = stored.wwCache || {};
      for (const [key, value] of Object.entries(cache)) {
        if (typeof value === "string" && value) memoryCache.set(key, value);
      }
      if (typeof stored.wwGoogleCooldown === "number") {
        googleCooldownUntil = stored.wwGoogleCooldown;
      }
    } catch {
      // ignore
    }
  }

  function scheduleDiskCachePersist() {
    if (!globalThis.chrome?.storage?.local || !diskCacheDirty) return;
    clearTimeout(diskCacheTimer);
    diskCacheTimer = setTimeout(async () => {
      diskCacheDirty = false;
      const obj = {};
      let count = 0;
      for (const [key, value] of memoryCache.entries()) {
        obj[key] = value;
        count += 1;
        if (count >= 1500) break;
      }
      try {
        await chrome.storage.local.set({
          wwCache: obj,
          wwGoogleCooldown: googleCooldownUntil,
        });
      } catch {
        // ignore quota errors
      }
    }, 800);
  }

  function putCache(targetLanguage, text, translated) {
    memoryCache.set(cacheKey(targetLanguage, text), translated);
    diskCacheDirty = true;
    scheduleDiskCachePersist();
  }

  function glossaryHit(text, targetLanguage) {
    return globalThis.WordWizardGlossary?.glossaryLookup?.(text, targetLanguage) || null;
  }

  async function fetchGoogle(text, targetLanguage) {
    if (Date.now() < googleCooldownUntil) {
      const err = new Error("Google translate cooling down after rate limit");
      err.code = "cooldown";
      throw err;
    }
    const tl = toGtxLanguage(targetLanguage);
    const url =
      "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=" +
      encodeURIComponent(tl) +
      "&dt=t&q=" +
      encodeURIComponent(text);
    const response = await fetch(url);
    if (response.status === 429) {
      googleCooldownUntil = Date.now() + 15 * 60 * 1000;
      diskCacheDirty = true;
      scheduleDiskCachePersist();
      const err = new Error("Online translation rate-limited (429)");
      err.code = "rate-limit";
      throw err;
    }
    if (!response.ok) {
      throw new Error(`Online translation HTTP ${response.status}`);
    }
    const data = await response.json();
    const translated = Array.isArray(data?.[0])
      ? data[0].map((part) => part?.[0] || "").join("")
      : "";
    if (!translated) throw new Error("Empty Google translation");
    return translated;
  }

  async function fetchMyMemory(text, targetLanguage) {
    const tl = toGtxLanguage(targetLanguage);
    const url =
      "https://api.mymemory.translated.net/get?q=" +
      encodeURIComponent(text) +
      "&langpair=en|" +
      encodeURIComponent(tl);
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`MyMemory HTTP ${response.status}`);
    }
    const data = await response.json();
    const translated = data?.responseData?.translatedText;
    if (!translated || /INVALID|MYMEMORY WARNING/i.test(translated)) {
      throw new Error("MyMemory returned no usable translation");
    }
    return translated;
  }

  async function fetchLingva(text, targetLanguage) {
    const tl = toGtxLanguage(targetLanguage);
    const url =
      "https://lingva.ml/api/v1/en/" +
      encodeURIComponent(tl) +
      "/" +
      encodeURIComponent(text);
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Lingva HTTP ${response.status}`);
    }
    const data = await response.json();
    if (!data?.translation) throw new Error("Empty Lingva translation");
    return data.translation;
  }

  async function throttleNetwork() {
    const wait = Math.max(0, MIN_NETWORK_GAP_MS - (Date.now() - lastNetworkAt));
    if (wait) await sleep(wait);
    lastNetworkAt = Date.now();
  }

  /**
   * Direct multi-provider fetch — intended for the service worker.
   */
  async function fetchOnlineTranslation(text, targetLanguage) {
    await ensureDiskCache();
    const trimmed = String(text || "").trim();
    if (!trimmed) return text;

    const key = cacheKey(targetLanguage, trimmed);
    if (memoryCache.has(key)) return memoryCache.get(key);

    const gloss = glossaryHit(trimmed, targetLanguage);
    if (gloss) {
      putCache(targetLanguage, trimmed, gloss);
      return gloss;
    }

    const providers = [
      { name: "google", run: () => fetchGoogle(trimmed, targetLanguage) },
      { name: "mymemory", run: () => fetchMyMemory(trimmed, targetLanguage) },
      { name: "lingva", run: () => fetchLingva(trimmed, targetLanguage) },
    ];

    let lastError = null;
    for (const provider of providers) {
      try {
        await throttleNetwork();
        const translated = await provider.run();
        putCache(targetLanguage, trimmed, translated);
        return translated;
      } catch (error) {
        lastError = error;
        // Keep trying other providers on rate limits / failures.
      }
    }

    throw lastError || new Error("All online translation providers failed");
  }

  function enqueueNetwork(task) {
    const run = requestChain.then(task, task);
    // Keep the chain alive even when a task fails.
    requestChain = run.catch(() => {});
    return run;
  }

  function sendRuntimeTranslate(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response?.ok) {
          reject(new Error(response?.error || "Online translation failed"));
          return;
        }
        resolve(response);
      });
    });
  }

  async function translateOnline(text, targetLanguage) {
    await ensureDiskCache();
    const trimmed = String(text || "").trim();
    if (!trimmed) return text;
    const key = cacheKey(targetLanguage, trimmed);
    if (memoryCache.has(key)) return memoryCache.get(key);

    const gloss = glossaryHit(trimmed, targetLanguage);
    if (gloss) {
      putCache(targetLanguage, trimmed, gloss);
      return gloss;
    }

    if (globalThis.chrome?.runtime?.id && !isServiceWorker()) {
      const response = await sendRuntimeTranslate({
        type: "ww:translate-online",
        text: trimmed,
        targetLanguage,
      });
      putCache(targetLanguage, trimmed, response.text);
      return response.text;
    }

    return enqueueNetwork(() => fetchOnlineTranslation(trimmed, targetLanguage));
  }

  /**
   * Translate many strings with glossary + cache first, then slow sequential network.
   */
  async function translateOnlineBatch(texts, targetLanguage) {
    await ensureDiskCache();
    const out = new Map();
    const pending = [];
    const seen = new Set();

    for (const raw of texts) {
      const text = String(raw || "").trim();
      if (!text || seen.has(text)) continue;
      seen.add(text);
      const key = cacheKey(targetLanguage, text);
      if (memoryCache.has(key)) {
        out.set(text, memoryCache.get(key));
        continue;
      }
      const gloss = glossaryHit(text, targetLanguage);
      if (gloss) {
        putCache(targetLanguage, text, gloss);
        out.set(text, gloss);
        continue;
      }
      pending.push(text);
    }

    // Cap network work per page pass to avoid another 429 storm.
    const networkBudget = 25;
    const toFetch = pending.slice(0, networkBudget);

    for (const item of toFetch) {
      try {
        const translated = await translateOnline(item, targetLanguage);
        out.set(item, translated);
      } catch (error) {
        // Leave untranslated rather than failing the whole page.
        console.warn("[Word Wizard] translate skipped:", item, error?.message || error);
      }
    }

    return out;
  }

  async function translateViaChrome(text, targetLanguage, onProgress) {
    const translator = await getTranslator(targetLanguage, onProgress);
    return translator.translate(text);
  }

  async function translateViaChromeBatch(texts, targetLanguage, onProgress) {
    const translator = await getTranslator(targetLanguage, onProgress);
    const unique = [...new Set(texts.map((t) => String(t || "").trim()).filter(Boolean))];
    const out = new Map();
    // Chrome is local/fast — parallelize a handful at a time.
    const concurrency = 12;
    for (let i = 0; i < unique.length; i += concurrency) {
      const slice = unique.slice(i, i + concurrency);
      const results = await Promise.all(
        slice.map(async (item) => {
          const key = cacheKey(targetLanguage, item);
          if (memoryCache.has(key)) return [item, memoryCache.get(key)];
          const translated = await translator.translate(item);
          memoryCache.set(key, translated);
          return [item, translated];
        })
      );
      for (const [item, translated] of results) out.set(item, translated);
    }
    return out;
  }

  /**
   * Fast path helpers: glossary + memory/disk cache only (no network).
   */
  async function translateLocalOnly(texts, targetLanguage) {
    await ensureDiskCache();
    const out = new Map();
    for (const raw of texts) {
      const text = String(raw || "").trim();
      if (!text) continue;
      const key = cacheKey(targetLanguage, text);
      if (memoryCache.has(key)) {
        out.set(text, memoryCache.get(key));
        continue;
      }
      const gloss = glossaryHit(text, targetLanguage);
      if (gloss) {
        putCache(targetLanguage, text, gloss);
        out.set(text, gloss);
      }
    }
    return out;
  }

  /**
   * Translate with preferred engine.
   * Default is Chrome on-device. Online is only used when engine === "online".
   */
  async function translateText(text, targetLanguage, onProgress, settings) {
    const trimmed = text.trim();
    if (!trimmed) return text;

    await ensureDiskCache();
    const key = cacheKey(targetLanguage, trimmed);
    if (memoryCache.has(key)) return memoryCache.get(key);

    const gloss = glossaryHit(trimmed, targetLanguage);
    if (gloss) {
      putCache(targetLanguage, trimmed, gloss);
      return gloss;
    }

    const cfg = settings || (await getSettings());
    const engine = cfg.engine || "chrome";

    if (engine === "online") {
      const translated = await translateOnline(trimmed, targetLanguage);
      putCache(targetLanguage, trimmed, translated);
      return translated;
    }

    // chrome or auto → on-device only (auto no longer falls back to slow online)
    const translated = await translateViaChrome(trimmed, targetLanguage, onProgress);
    putCache(targetLanguage, trimmed, translated);
    return translated;
  }

  /**
   * Batch translate. Uses Chrome packs for speed; online only if explicitly selected.
   */
  async function translateMany(texts, targetLanguage, settings) {
    const cfg = settings || (await getSettings());
    const engine = cfg.engine || "chrome";
    const list = texts.map((t) => String(t || "").trim()).filter(Boolean);

    // Always seed from local glossary/cache first (instant).
    const local = await translateLocalOnly(list, targetLanguage);
    const missing = list.filter((t) => !local.has(t));
    if (!missing.length) return local;

    if (engine === "online") {
      const online = await translateOnlineBatch(missing, targetLanguage);
      for (const [k, v] of online) local.set(k, v);
      return local;
    }

    try {
      const chromeMap = await translateViaChromeBatch(missing, targetLanguage);
      for (const [k, v] of chromeMap) local.set(k, v);
      if (!cfg.chromePackReady) {
        await saveSettings({ chromePackReady: true });
      }
    } catch (error) {
      chromeUnusable = true;
      await saveSettings({ chromePackReady: false });
      throw error;
    }
    return local;
  }

  function rememberChromeUnusable() {
    chromeUnusable = true;
  }

  async function probeChromePack(targetLanguage) {
    if (!translatorSupported()) return { ok: false, reason: "unsupported" };
    const availability = await checkPairAvailability(targetLanguage);
    if (availability === "available") {
      return { ok: true, reason: "available", availability };
    }
    if (availability === "downloadable" || availability === "downloading") {
      return { ok: false, reason: "needs-download", availability };
    }
    return { ok: false, reason: "unavailable", availability };
  }

  globalThis.WordWizard = {
    TARGET_LANGUAGES,
    FREQUENCY_MODES,
    COLOR_THEMES,
    DEFAULT_SETTINGS,
    SKIP_WORDS,
    hashString,
    shouldPick,
    getSettings,
    saveSettings,
    translatorSupported,
    getBrowserInfo,
    hasUserActivation,
    checkPairAvailability,
    startTranslatorCreate,
    getTranslator,
    fetchOnlineTranslation,
    translateOnline,
    translateOnlineBatch,
    translateLocalOnly,
    translateText,
    translateMany,
    rememberChromeUnusable,
    probeChromePack,
    hostMatchesSearchEngine,
    isSearchEngineLocation,
  };
})();
