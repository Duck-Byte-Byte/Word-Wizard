# Word Wizard

Learn languages while browsing **websites** (search engines are blacklisted). Word Wizard swaps selected words into your target language using **on-device Translator packs in Google Chrome or Microsoft Edge** for near-instant results.

Online translation exists only as a slow backup — it is rate-limited and not used by default.

## Supported browsers

| Browser | Minimum version | Pack manager |
| --- | --- | --- |
| Google Chrome (desktop) | 138+ | `chrome://on-device-translation-internals/` |
| Microsoft Edge (desktop) | 148+ | `edge://on-device-translation-internals/` |

## Setup (important for speed)

1. Load the unpacked extension in Chrome or Edge.
2. Open the popup → **Set up on-device pack**.
3. Click **Download / verify on-device pack** and wait until it says Ready.
4. Browse a normal website (not Google/Bing/etc.).

### Edge notes

Edge often needs packs installed before `Translator.create()` works:

1. Open `edge://on-device-translation-internals/` and install `en` + your target language.
2. Open `edge://components/` and update **Chrome TranslateKit** / **EdgeLLMRuntime** if stuck at `0.0.0.0`.
3. Add those languages under Edge → Settings → Languages.
4. Restart Edge, then click **Download / verify** again.

## Features

- Fast **on-device** translation via the Chromium Translator API (Chrome + Edge)
- Instant first paint from a built-in glossary + disk cache
- Color themes with a regular system font
- Search-engine blacklist
- Optional slow online engine (not recommended)

## Settings

| Control | What it does |
| --- | --- |
| Spellcasting | On/off |
| Translate into | Target language |
| Engine | On-device (Chrome / Edge) / Online (slow backup) |
| Color theme | Yellow / Blue / Green / Orange / Pink / Gray |
| How often | Rare / Often / Full sentences |

## Demo

```bash
npm start
```

Open `http://127.0.0.1:8765/demo/`.
