(() => {
  const WW = globalThis.WordWizard;
  if (!WW) {
    console.warn("[Word Wizard] shared.js failed to load");
    return;
  }

  if (WW.isSearchEngineLocation()) {
    return;
  }

  const STATE = {
    settings: { ...WW.DEFAULT_SETTINGS },
    running: false,
    refreshDirty: false,
    observer: null,
    queue: Promise.resolve(),
    wordIndex: 0,
    sentenceCounter: 0,
  };

  const SKIP_TAGS = new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "TEXTAREA",
    "INPUT",
    "SELECT",
    "OPTION",
    "CODE",
    "PRE",
    "KBD",
    "SAMP",
    "SVG",
    "MATH",
    "BUTTON",
    "LABEL",
    "A",
  ]);

  const WORD_RE = /(\p{L}[\p{L}'’-]*|\s+|[^ \t\n\r\p{L}]+)/gu;

  function ensureTooltip() {
    let tip = document.getElementById("ww-tooltip");
    if (tip) return tip;
    tip = document.createElement("div");
    tip.id = "ww-tooltip";
    tip.setAttribute("role", "tooltip");
    tip.innerHTML =
      '<span class="ww-tip-label">English</span><span class="ww-tip-text"></span>';
    document.documentElement.appendChild(tip);
    return tip;
  }

  function showTooltip(target) {
    const tip = ensureTooltip();
    tip.querySelector(".ww-tip-text").textContent =
      target.getAttribute("data-ww-original") || "";
    const rect = target.getBoundingClientRect();
    const tipWidth = Math.min(280, window.innerWidth - 24);
    let left = rect.left + rect.width / 2 - tipWidth / 2;
    left = Math.max(12, Math.min(left, window.innerWidth - tipWidth - 12));
    tip.style.maxWidth = `${tipWidth}px`;
    tip.classList.add("ww-visible");
    requestAnimationFrame(() => {
      const height = tip.offsetHeight || 48;
      let nextTop = rect.top - height - 10;
      if (nextTop < 8) nextTop = rect.bottom + 10;
      tip.style.left = `${left}px`;
      tip.style.top = `${nextTop}px`;
    });
  }

  function hideTooltip() {
    document.getElementById("ww-tooltip")?.classList.remove("ww-visible");
  }

  function bindTooltipEvents(el) {
    el.addEventListener("mouseenter", () => showTooltip(el));
    el.addEventListener("mouseleave", hideTooltip);
    el.addEventListener("focus", () => showTooltip(el));
    el.addEventListener("blur", hideTooltip);
  }

  function createMark(tagClass, original, translated) {
    const mark = document.createElement("span");
    mark.className = tagClass;
    mark.setAttribute("data-ww-original", original);
    mark.setAttribute("tabindex", "0");
    mark.setAttribute("lang", STATE.settings.targetLanguage);
    mark.textContent = translated;
    bindTooltipEvents(mark);
    return mark;
  }

  function enqueue(task) {
    STATE.queue = STATE.queue.then(task).catch((err) => {
      console.warn("[Word Wizard]", err);
    });
    return STATE.queue;
  }

  function isSkippableNode(node) {
    if (!node || node.nodeType !== Node.TEXT_NODE) return true;
    if (!node.nodeValue || !node.nodeValue.trim()) return true;
    const parent = node.parentElement;
    if (!parent) return true;
    if (parent.closest(".ww-word, .ww-sentence, #ww-tooltip, #ww-pack-hint, [contenteditable='true']")) {
      return true;
    }
    if (SKIP_TAGS.has(parent.tagName)) return true;
    if (parent.isContentEditable) return true;
    if (
      parent.closest(
        "nav, header, footer, form, [role='navigation'], [role='search'], [role='banner'], [role='contentinfo'], [role='menu'], [role='menubar']"
      )
    ) {
      return true;
    }
    return false;
  }

  function applyColorTheme(theme) {
    const allowed = new Set(WW.COLOR_THEMES.map((t) => t.id));
    document.documentElement.dataset.wwColor = allowed.has(theme)
      ? theme
      : "yellow";
  }

  function preferredRoots() {
    const main = document.querySelector(
      "main, article, [role='main'], #content, .content, .post, .entry-content"
    );
    return [main || document.body].filter(Boolean);
  }

  function collectTextNodes(root) {
    const nodes = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (isSkippableNode(node)) return NodeFilter.FILTER_REJECT;
        // Prefer visible-ish text; skip tiny/collapsed
        const parent = node.parentElement;
        if (parent) {
          const style = parent.ownerDocument?.defaultView?.getComputedStyle?.(parent);
          if (style && (style.display === "none" || style.visibility === "hidden")) {
            return NodeFilter.FILTER_REJECT;
          }
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    let current = walker.nextNode();
    while (current) {
      nodes.push(current);
      current = walker.nextNode();
    }
    return nodes;
  }

  function frequencyRate(mode) {
    if (mode === "rare") return 0.08;
    if (mode === "often") return 0.28;
    return 0;
  }

  function splitSentences(text) {
    const pieces = [];
    const re = /[^.!?…]+[.!?…]+|[^.!?…]+$/g;
    let match;
    while ((match = re.exec(text)) !== null) pieces.push(match[0]);
    return pieces.length ? pieces : [text];
  }

  function planWordJobs(nodes, rate) {
    const jobs = [];
    for (const textNode of nodes) {
      const text = textNode.nodeValue;
      if (!text || !text.trim()) continue;
      const parts = text.match(WORD_RE);
      if (!parts) continue;

      const plan = [];
      let localIndex = 0;
      let needsWork = false;
      for (const part of parts) {
        const isWord = /^\p{L}/u.test(part);
        if (!isWord) {
          plan.push({ type: "text", value: part });
          continue;
        }
        const lower = part.toLowerCase();
        const eligible =
          part.length > 2 &&
          !WW.SKIP_WORDS.has(lower) &&
          WW.shouldPick(part, STATE.wordIndex + localIndex, rate);
        localIndex += 1;
        if (!eligible) {
          plan.push({ type: "text", value: part });
          continue;
        }
        plan.push({ type: "word", value: part });
        needsWork = true;
      }
      STATE.wordIndex += localIndex;
      if (needsWork) jobs.push({ textNode, plan });
    }
    return jobs;
  }

  function planSentenceJobs(nodes) {
    const jobs = [];
    for (const textNode of nodes) {
      const text = textNode.nodeValue;
      if (!text || text.trim().length < 24) continue;
      const sentences = splitSentences(text);
      const plan = [];
      let needsWork = false;
      for (const sentence of sentences) {
        const trimmed = sentence.trim();
        const shouldTranslate = trimmed.length >= 24 && STATE.sentenceCounter % 3 === 1;
        if (trimmed) STATE.sentenceCounter += 1;
        if (!shouldTranslate) {
          plan.push({ type: "text", value: sentence });
          continue;
        }
        plan.push({
          type: "sentence",
          value: sentence,
          trimmed,
          leading: sentence.match(/^\s*/)?.[0] || "",
          trailing: sentence.match(/\s*$/)?.[0] || "",
        });
        needsWork = true;
      }
      if (needsWork) jobs.push({ textNode, plan });
    }
    return jobs;
  }

  function applyJobs(jobs, translations) {
    for (const job of jobs) {
      if (!job.textNode.isConnected) continue;
      const frag = document.createDocumentFragment();
      let changed = false;
      for (const item of job.plan) {
        if (item.type === "text") {
          frag.appendChild(document.createTextNode(item.value));
          continue;
        }
        const source = item.type === "word" ? item.value : item.trimmed;
        const translated = translations.get(source);
        if (!translated || translated === source) {
          frag.appendChild(document.createTextNode(item.value));
          continue;
        }
        if (item.type === "sentence") {
          if (item.leading) frag.appendChild(document.createTextNode(item.leading));
          frag.appendChild(createMark("ww-sentence", item.trimmed, translated));
          if (item.trailing) frag.appendChild(document.createTextNode(item.trailing));
        } else {
          frag.appendChild(createMark("ww-word", item.value, translated));
        }
        changed = true;
      }
      if (changed && job.textNode.parentNode) {
        job.textNode.parentNode.replaceChild(frag, job.textNode);
      }
    }
  }

  function showPackHint() {
    if (document.getElementById("ww-pack-hint")) return;
    const bar = document.createElement("div");
    bar.id = "ww-pack-hint";
    bar.setAttribute("role", "status");
    bar.innerHTML =
      "Word Wizard needs an on-device language pack (Chrome or Edge) for fast translations. Open the extension → <strong>Set up on-device pack</strong>.";
    document.documentElement.appendChild(bar);
    setTimeout(() => bar.remove(), 10000);
  }

  async function processRoot(root) {
    if (!STATE.settings.enabled) return;
    if (WW.isSearchEngineLocation()) return;

    applyColorTheme(STATE.settings.colorTheme || "yellow");

    const nodes = collectTextNodes(root);
    const mode = STATE.settings.frequency;
    const jobs =
      mode === "sentences"
        ? planSentenceJobs(nodes)
        : planWordJobs(nodes, frequencyRate(mode));
    if (!jobs.length) return;

    const toTranslate = [];
    for (const job of jobs) {
      for (const item of job.plan) {
        if (item.type === "word") toTranslate.push(item.value);
        if (item.type === "sentence") toTranslate.push(item.trimmed);
      }
    }

    // 1) Instant local pass (glossary + disk cache) — should feel immediate.
    const local = await WW.translateLocalOnly(
      toTranslate,
      STATE.settings.targetLanguage
    );
    if (local.size) applyJobs(jobs, local);

    const missing = toTranslate.filter((t) => !local.has(t));
    if (!missing.length) return;

    const engine = STATE.settings.engine || "chrome";

    // 2) On-device Chrome pack (fast). Skip slow online unless explicitly chosen.
    if (engine === "online") {
      try {
        const online = await WW.translateOnlineBatch(
          missing.slice(0, 20),
          STATE.settings.targetLanguage
        );
        if (online.size) applyJobs(jobs, new Map([...local, ...online]));
      } catch (err) {
        console.warn("[Word Wizard]", err);
      }
      return;
    }

    try {
      // Warm translator once, then translate remaining words in parallel locally.
      await WW.getTranslator(STATE.settings.targetLanguage);
      const chromeMap = await WW.translateMany(
        missing,
        STATE.settings.targetLanguage,
        { ...STATE.settings, engine: "chrome" }
      );
      applyJobs(jobs, new Map([...local, ...chromeMap]));
    } catch (err) {
      WW.rememberChromeUnusable?.();
      showPackHint();
      console.warn("[Word Wizard] on-device pack needed:", err?.message || err);
    }
  }

  function restorePage() {
    document.querySelectorAll(".ww-word, .ww-sentence").forEach((el) => {
      const original = el.getAttribute("data-ww-original");
      el.replaceWith(document.createTextNode(original || el.textContent || ""));
    });
    hideTooltip();
  }

  async function refresh() {
    if (WW.isSearchEngineLocation()) return;
    if (STATE.running) {
      // A settings change arrived mid-run — loop again with latest values.
      STATE.refreshDirty = true;
      return;
    }
    STATE.running = true;
    try {
      do {
        STATE.refreshDirty = false;
        STATE.settings = await WW.getSettings();
        applyColorTheme(STATE.settings.colorTheme || "yellow");
        restorePage();
        STATE.wordIndex = 0;
        STATE.sentenceCounter = 0;
        if (!STATE.settings.enabled) continue;
        for (const root of preferredRoots()) {
          if (STATE.refreshDirty) break;
          await processRoot(root);
        }
      } while (STATE.refreshDirty);
    } finally {
      STATE.running = false;
      if (STATE.refreshDirty) {
        STATE.refreshDirty = false;
        enqueue(() => refresh());
      }
    }
  }

  function scheduleRefresh() {
    enqueue(() => refresh());
  }

  function observe() {
    if (STATE.observer) STATE.observer.disconnect();
    STATE.observer = new MutationObserver((mutations) => {
      if (!STATE.settings.enabled) return;
      const roots = new Set();
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          if (
            node.id === "ww-tooltip" ||
            node.id === "ww-pack-hint" ||
            node.classList?.contains("ww-word") ||
            node.classList?.contains("ww-sentence")
          ) {
            continue;
          }
          roots.add(node);
        }
      }
      if (!roots.size) return;
      clearTimeout(observe._timer);
      observe._timer = setTimeout(() => {
        enqueue(async () => {
          if (!STATE.settings.enabled) return;
          for (const root of roots) {
            if (root.isConnected) await processRoot(root);
          }
        });
      }, 350);
    });
    STATE.observer.observe(document.body, { childList: true, subtree: true });
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "ww:settings-changed") {
      scheduleRefresh();
      return;
    }
    if (message?.type === "ww:force-refresh") {
      scheduleRefresh();
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    // Language / frequency changes are handled by an active-tab reload from the popup.
    // Soft-refresh for everything else so color/enabled/engine still update live.
    if (changes.targetLanguage || changes.frequency) return;
    scheduleRefresh();
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      scheduleRefresh();
      observe();
    });
  } else {
    scheduleRefresh();
    observe();
  }
})();
