(() => {
  const WW = globalThis.WordWizard;
  const browser = WW.getBrowserInfo();
  const languageEl = document.getElementById("targetLanguage");
  const installBtn = document.getElementById("install");
  const statusEl = document.getElementById("status");
  const logEl = document.getElementById("log");
  const browserPill = document.getElementById("browser-pill");
  const helpSteps = document.getElementById("help-steps");
  const chromeGuide = document.getElementById("chrome-guide");
  const edgeGuide = document.getElementById("edge-guide");

  function log(line) {
    const stamp = new Date().toLocaleTimeString();
    logEl.textContent += `[${stamp}] ${line}\n`;
    logEl.scrollTop = logEl.scrollHeight;
  }

  function setStatus(text, kind) {
    statusEl.className = "status";
    if (kind) statusEl.classList.add(kind);
    statusEl.textContent = text;
  }

  function fillLanguages(selected) {
    languageEl.innerHTML = "";
    for (const lang of WW.TARGET_LANGUAGES) {
      const option = document.createElement("option");
      option.value = lang.code;
      option.textContent = lang.label;
      languageEl.appendChild(option);
    }
    languageEl.value = selected || "es";
  }

  function openInternals(url) {
    chrome.tabs.create({ url });
  }

  function wireButton(id, url) {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("click", () => openInternals(url));
  }

  function renderBrowserHelp() {
    document.body.classList.toggle("is-edge", Boolean(browser.isEdge));
    browserPill.textContent = `${browser.name}${
      browser.version ? ` ${browser.version}` : ""
    }`;

    if (browser.isEdge) {
      chromeGuide.style.display = "none";
      edgeGuide.style.display = "block";
    } else {
      chromeGuide.style.display = "block";
      helpSteps.innerHTML = `
        <li>Use ${browser.label} (desktop only — not mobile).</li>
        <li>
          Open <code>${browser.translationInternalsUrl}</code> and confirm packs
          for <code>en</code> and your target language are installed.
        </li>
        <li>Also check <code>${browser.onDeviceInternalsUrl}</code> for errors.</li>
        <li>Update ${browser.name}, restart it, then click the download button again.</li>
      `;
    }

    wireButton("open-translation-internals", browser.translationInternalsUrl);
    wireButton("open-translation-internals-chrome", browser.translationInternalsUrl);
    wireButton("open-ai-internals", browser.onDeviceInternalsUrl);
    wireButton("open-ai-internals-chrome", browser.onDeviceInternalsUrl);
    wireButton("open-components", browser.componentsUrl);
    wireButton("open-languages", browser.languagesSettingsUrl);
  }

  function describeFailure(err, availability) {
    const raw = String(err?.cause?.message || err?.message || err || "");
    const code = err?.code || err?.name || "";
    if (browser.isEdge) {
      if (code === "not-supported" || /Unable to create translator|NotSupported/i.test(raw)) {
        return (
          "Edge still can’t create this translator. Install en + your language in the " +
          "language pack manager, fix TranslateKit in Components if needed, restart Edge, then verify again."
        );
      }
      if (code === "timeout") {
        return (
          "Edge timed out while downloading. Leave the language pack manager open until packs show Installed, restart Edge, then verify."
        );
      }
      if (code === "needs-gesture") {
        return "Click the download button directly — Edge needs a real click to start the download.";
      }
    }
    if (availability === "unavailable") {
      return "This language pair is unavailable on this device right now.";
    }
    return `${browser.name} could not finish pack setup yet. See the log below, then use the steps underneath.`;
  }

  async function init() {
    renderBrowserHelp();
    log(`Browser: ${browser.name} ${browser.version || "?"} (min ${browser.minVersion})`);
    log(`Translator API: ${WW.translatorSupported() ? "present" : "MISSING"}`);

    const settings = await WW.getSettings();
    const params = new URLSearchParams(location.search);
    fillLanguages(params.get("lang") || settings.targetLanguage);

    if (!browser.supportedVersion && browser.version) {
      setStatus(
        `${browser.name} ${browser.version} may be too old. Use version ${browser.minVersion}+.`,
        "is-warn"
      );
      log(`Version below recommended minimum (${browser.minVersion}).`);
    }

    if (!WW.translatorSupported()) {
      setStatus(
        `Translator API not found. Use ${browser.label}, then reopen this page.`,
        "is-bad"
      );
      installBtn.disabled = true;
      log("Translator global is missing.");
      return;
    }

    const availability = await WW.checkPairAvailability(languageEl.value);
    log(`availability(en → ${languageEl.value}) = ${availability}`);
    if (availability === "available") {
      setStatus("Pack already installed on this device.", "is-ok");
      await WW.saveSettings({
        targetLanguage: languageEl.value,
        engine: "chrome",
        chromePackReady: true,
      });
    } else if (availability === "unavailable") {
      setStatus(
        browser.isEdge
          ? "Edge reports this pair unavailable. Install packs in the checklist below, then verify."
          : "This language pair is unavailable here. Install packs in the language pack manager, then retry.",
        "is-bad"
      );
    } else if (browser.isEdge) {
      setStatus(
        "On Edge: install packs with the checklist below, then click Download / verify.",
        "is-warn"
      );
    } else {
      setStatus(
        `Click Download / verify to install the pack in ${browser.name}.`,
        "is-warn"
      );
    }
  }

  installBtn.addEventListener("click", () => {
    const code = languageEl.value;
    setStatus(`Working with ${browser.name} on-device pack…`, "is-warn");
    installBtn.disabled = true;
    log(`Starting Translator.create(en → ${code}) on ${browser.name}`);
    log(`userActivation=${WW.hasUserActivation() ? "active" : "inactive"}`);

    // Capture availability after the create attempt for better errors (not before — keeps the gesture).
    let availabilityAfter = "";

    const pending = WW.startTranslatorCreate(code, (pct) => {
      setStatus(
        pct > 0
          ? `Downloading on-device pack… ${pct}%`
          : `Downloading / verifying pack in ${browser.name}…`,
        "is-warn"
      );
      if (pct > 0) log(`download progress ${pct}%`);
    });

    pending
      .then(async (result) => {
        const translator = result?.translator || result;
        const sample =
          result?.sample ||
          (await translator.translate("The quick brown fox").catch(() => ""));
        if (sample) {
          log(`smoke test: "The quick brown fox" → "${sample}"`);
        } else {
          log("create() succeeded; smoke translation skipped or empty (still marking ready).");
        }
        await WW.saveSettings({
          targetLanguage: code,
          engine: "chrome",
          chromePackReady: true,
        });
        setStatus(
          `Ready — on-device pack is usable in ${browser.name}. Close this tab and browse any website.`,
          "is-ok"
        );
        log("chromePackReady=true, engine=chrome");
      })
      .catch(async (err) => {
        try {
          availabilityAfter = await WW.checkPairAvailability(code);
          log(`availability after failure = ${availabilityAfter}`);
        } catch {
          availabilityAfter = "";
        }
        log(`FAILED: ${err?.name || err?.code || "Error"}: ${err?.message || err}`);
        if (err?.cause) {
          log(
            `cause: ${err.cause?.name || ""} ${err.cause?.message || err.cause}`.trim()
          );
        }
        setStatus(describeFailure(err, availabilityAfter), "is-bad");
        WW.saveSettings({ chromePackReady: false });
      })
      .finally(() => {
        installBtn.disabled = false;
      });
  });

  languageEl.addEventListener("change", async () => {
    const code = languageEl.value;
    await WW.saveSettings({ targetLanguage: code, chromePackReady: false });
    const availability = await WW.checkPairAvailability(code);
    log(`availability(en → ${code}) = ${availability}`);
    setStatus(
      availability === "available"
        ? "Pack already installed for this language."
        : availability === "unavailable"
          ? browser.isEdge
            ? "Unavailable — install packs with the Edge checklist, then verify."
            : "Unavailable — install language packs in the manager, then retry."
          : browser.isEdge
            ? "Install packs with the Edge checklist, then click Download / verify."
            : `Click Download / verify to install it in ${browser.name}.`,
      availability === "available"
        ? "is-ok"
        : availability === "unavailable"
          ? "is-bad"
          : "is-warn"
    );
  });

  init();
})();
