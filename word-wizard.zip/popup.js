(() => {
  const WW = globalThis.WordWizard;
  const browser = WW.getBrowserInfo();
  const enabledEl = document.getElementById("enabled");
  const enabledHint = document.getElementById("enabled-hint");
  const languageEl = document.getElementById("targetLanguage");
  const langStatus = document.getElementById("lang-status");
  const setupBtn = document.getElementById("setup-pack");
  const engineEl = document.getElementById("engine");
  const colorThemeEl = document.getElementById("colorTheme");
  const frequencyEl = document.getElementById("frequency");
  const apiStatus = document.getElementById("api-status");

  function fillLanguages() {
    languageEl.innerHTML = "";
    for (const lang of WW.TARGET_LANGUAGES) {
      const option = document.createElement("option");
      option.value = lang.code;
      option.textContent = lang.label;
      languageEl.appendChild(option);
    }
  }

  function fillFrequency(selected) {
    frequencyEl.innerHTML = "";
    for (const mode of WW.FREQUENCY_MODES) {
      const label = document.createElement("label");
      label.className = "freq-option";
      label.innerHTML = `
        <input type="radio" name="frequency" value="${mode.id}" />
        <span>
          <strong>${mode.label}</strong>
          <span>${mode.hint}</span>
        </span>
      `;
      const input = label.querySelector("input");
      input.checked = mode.id === selected;
      input.addEventListener("change", async () => {
        if (!input.checked) return;
        await WW.saveSettings({ frequency: mode.id });
        reloadActivePage();
      });
      frequencyEl.appendChild(label);
    }
  }

  function isExtensionRuntime() {
    return Boolean(globalThis.chrome?.runtime?.id);
  }

  function setStatus(text, kind) {
    langStatus.className = "status";
    if (kind) langStatus.classList.add(kind);
    langStatus.textContent = text;
  }

  async function refreshLanguageStatus(code) {
    if (!isExtensionRuntime()) {
      setStatus(
        "Preview only — load the unpacked extension in Chrome or Edge.",
        "is-warn"
      );
      return;
    }

    const settings = await WW.getSettings();
    const engine = settings.engine || "chrome";

    if (engine === "online") {
      setStatus(
        "Online mode is slow by design. Switch to On-device (Chrome / Edge) for instant pages.",
        "is-warn"
      );
      return;
    }

    if (!WW.translatorSupported()) {
      setStatus(
        `Translator API missing. Use ${browser.label}, then Set up on-device pack.`,
        "is-bad"
      );
      return;
    }

    if (browser.version && !browser.supportedVersion) {
      setStatus(
        `${browser.name} ${browser.version} may be too old (need ${browser.minVersion}+).`,
        "is-warn"
      );
    }

    const probe = await WW.probeChromePack(code);
    if (probe.ok) {
      await WW.saveSettings({ chromePackReady: true, engine: "chrome" });
      if (engineEl) engineEl.value = "chrome";
      setStatus(
        `Ready — on-device pack is installed in ${browser.name}. Browse a website for instant practice.`,
        "is-ok"
      );
      return;
    }

    await WW.saveSettings({ chromePackReady: false });
    if (probe.reason === "needs-download") {
      setStatus(
        `On-device pack not installed in ${browser.name} yet. Click Set up on-device pack.`,
        "is-warn"
      );
      return;
    }

    setStatus(
      `${browser.name} can’t serve this pack yet. Open Set up on-device pack (and the language pack manager).`,
      "is-bad"
    );
  }

  function updateApiBanner() {
    if (!isExtensionRuntime()) {
      apiStatus.textContent = "Demo preview only.";
      return;
    }
    const engine = engineEl?.value || "chrome";
    if (engine === "online") {
      apiStatus.textContent =
        "Online backup is rate-limited and slow — use only if on-device setup fails.";
      return;
    }
    apiStatus.textContent = WW.translatorSupported()
      ? `On-device mode in ${browser.name} — translations stay on your computer and should feel instant.`
      : `Install ${browser.label} to use on-device packs.`;
  }

  function syncEnabledCopy(on) {
    enabledHint.textContent = on
      ? "Translating words on websites (search engines excluded)"
      : "Paused — pages stay in English";
  }

  function reloadActivePage() {
    if (!isExtensionRuntime()) return;
    chrome.runtime.sendMessage({ type: "ww:reload-active-tab" }, () => {
      void chrome.runtime.lastError;
    });
  }

  async function init() {
    fillLanguages();
    const settings = await WW.getSettings();
    const engine =
      settings.engine === "auto" ? "chrome" : settings.engine || "chrome";
    if (settings.engine === "auto") {
      await WW.saveSettings({ engine: "chrome" });
    }

    enabledEl.checked = Boolean(settings.enabled);
    syncEnabledCopy(settings.enabled);
    languageEl.value = settings.targetLanguage;
    if (engineEl) engineEl.value = engine === "online" ? "online" : "chrome";
    if (colorThemeEl) colorThemeEl.value = settings.colorTheme || "yellow";
    fillFrequency(settings.frequency);
    updateApiBanner();
    await refreshLanguageStatus(settings.targetLanguage);

    enabledEl.addEventListener("change", async () => {
      await WW.saveSettings({ enabled: enabledEl.checked });
      syncEnabledCopy(enabledEl.checked);
    });

    languageEl.addEventListener("change", async () => {
      const code = languageEl.value;
      await WW.saveSettings({
        targetLanguage: code,
        chromePackReady: false,
      });
      await refreshLanguageStatus(code);
      reloadActivePage();
    });

    engineEl?.addEventListener("change", async () => {
      await WW.saveSettings({ engine: engineEl.value });
      updateApiBanner();
      await refreshLanguageStatus(languageEl.value);
    });

    colorThemeEl?.addEventListener("change", async () => {
      await WW.saveSettings({ colorTheme: colorThemeEl.value });
    });

    setupBtn.addEventListener("click", () => {
      const url = chrome.runtime.getURL(
        `install.html?lang=${encodeURIComponent(languageEl.value)}`
      );
      chrome.tabs.create({ url });
    });
  }

  init();
})();
