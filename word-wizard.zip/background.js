importScripts("glossary.js", "shared.js");

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.sync.get(null);
  const patch = {};
  if (Object.keys(current).length === 0) {
    Object.assign(patch, WordWizard.DEFAULT_SETTINGS);
  } else {
    if (!current.colorTheme) patch.colorTheme = "yellow";
    if (current.engine === "auto") patch.engine = "chrome";
  }
  if (Object.keys(patch).length) {
    await chrome.storage.sync.set(patch);
  }
});

function isHttpTab(tab) {
  return Boolean(tab?.id && tab.url && /^https?:\/\//i.test(tab.url));
}

function notifyTabs() {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (!isHttpTab(tab)) continue;
      chrome.tabs.sendMessage(
        tab.id,
        { type: "ww:settings-changed" },
        () => {
          void chrome.runtime.lastError;
        }
      );
    }
  });
}

function reloadActiveHttpTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs?.[0];
    if (!isHttpTab(tab)) return;
    chrome.tabs.reload(tab.id, { bypassCache: false }, () => {
      void chrome.runtime.lastError;
    });
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  // Language / frequency: popup asks for a hard reload so picks restart cleanly.
  if (changes.targetLanguage || changes.frequency) return;
  notifyTabs();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "ww:reload-active-tab") {
    reloadActiveHttpTab();
    sendResponse?.({ ok: true });
    return false;
  }

  if (message?.type !== "ww:translate-online") return undefined;

  WordWizard.translateOnline(message.text, message.targetLanguage)
    .then((text) => sendResponse({ ok: true, text }))
    .catch((error) =>
      sendResponse({
        ok: false,
        error: error?.message || String(error),
      })
    );
  return true;
});
