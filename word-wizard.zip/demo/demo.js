const DICTIONARIES = {
  es: {
    immersion: "inmersión",
    everyday: "cotidiana",
    reading: "lectura",
    practice: "práctica",
    familiar: "familiares",
    pages: "páginas",
    foreign: "extranjeras",
    words: "palabras",
    mixed: "mezcladas",
    helps: "ayuda",
    brain: "cerebro",
    attach: "vincular",
    meaning: "significado",
    vocabulary: "vocabulario",
    without: "sin",
    flashcards: "tarjetas",
    slowly: "despacio",
    hover: "pasa el cursor",
    hints: "pistas",
    raise: "aumenta",
    frequency: "frecuencia",
    phrases: "frases",
    begin: "empiezan",
    feel: "sentirse",
    natural: "naturales",
    translator: "traductor",
    makes: "hace",
    learning: "aprendizaje",
    possible: "posible",
    built: "integrada",
    runs: "funciona",
    computer: "computadora",
    private: "privado",
    fast: "rápido",
    replace: "reemplazar",
    selected: "seleccionadas",
    search: "búsqueda",
    engine: "motor",
    results: "resultados",
    reveals: "revela",
    english: "inglés",
    original: "original",
    gentle: "suave",
    routine: "rutina",
    busy: "ocupadas",
    people: "personas",
    another: "otro",
    language: "idioma",
    minutes: "minutos",
    curious: "curioso",
    hovering: "pasar el cursor",
    during: "durante",
    normal: "normal",
    session: "sesión",
    teach: "enseñar",
    durable: "duraderas",
    isolated: "aisladas",
    consistency: "constancia",
    beats: "supera",
    intensity: "intensidad",
    goal: "objetivo",
    comfortable: "cómoda",
    recall: "memoria",
    marked: "marcadas",
    fonts: "fuentes",
    notice: "notar",
    distinct: "distinta",
    italic: "cursiva",
    typeface: "tipografía",
    signals: "señala",
    transformed: "transformada",
    extension: "extensión",
    visual: "visual",
    trains: "entrena",
    pause: "pausar",
    guess: "adivinar",
    check: "revisar",
    tooltip: "información",
    need: "necesitas",
  },
  fr: {
    immersion: "immersion",
    everyday: "quotidienne",
    reading: "lecture",
    practice: "pratique",
    familiar: "familières",
    pages: "pages",
    foreign: "étrangers",
    words: "mots",
    mixed: "mélangés",
    helps: "aide",
    brain: "cerveau",
    attach: "associer",
    meaning: "sens",
    vocabulary: "vocabulaire",
    without: "sans",
    flashcards: "fiches",
    slowly: "lentement",
    hover: "survolez",
    hints: "indices",
    raise: "augmentez",
    frequency: "fréquence",
    phrases: "phrases",
    begin: "commencent",
    feel: "sembler",
    natural: "naturelles",
    translator: "traducteur",
    makes: "rend",
    learning: "apprentissage",
    possible: "possible",
    built: "intégrée",
    runs: "fonctionne",
    computer: "ordinateur",
    private: "privé",
    fast: "rapide",
    replace: "remplacer",
    selected: "sélectionnés",
    search: "recherche",
    engine: "moteur",
    results: "résultats",
    reveals: "révèle",
    english: "anglais",
    original: "original",
    gentle: "douce",
    routine: "routine",
    busy: "occupées",
    people: "personnes",
    another: "une autre",
    language: "langue",
    minutes: "minutes",
    curious: "curieux",
    hovering: "survol",
    during: "pendant",
    normal: "normale",
    session: "session",
    teach: "enseigner",
    durable: "durables",
    isolated: "isolés",
    consistency: "régularité",
    beats: "bat",
    intensity: "intensité",
    goal: "objectif",
    comfortable: "confortable",
    recall: "rappel",
    marked: "marquées",
    fonts: "polices",
    notice: "remarquer",
    distinct: "distincte",
    italic: "italique",
    typeface: "police",
    signals: "signale",
    transformed: "transformé",
    extension: "extension",
    visual: "visuel",
    trains: "entraîne",
    pause: "faire une pause",
    guess: "deviner",
    check: "vérifier",
    tooltip: "infobulle",
    need: "avez besoin",
  },
  de: {
    immersion: "Immersion",
    everyday: "alltägliche",
    reading: "Lesen",
    practice: "Übung",
    familiar: "vertraute",
    pages: "Seiten",
    foreign: "fremden",
    words: "Wörter",
    mixed: "gemischt",
    helps: "hilft",
    brain: "Gehirn",
    attach: "verknüpfen",
    meaning: "Bedeutung",
    vocabulary: "Wortschatz",
    without: "ohne",
    flashcards: "Karteikarten",
    slowly: "langsam",
    hover: "schweben",
    hints: "Hinweise",
    raise: "erhöhen",
    frequency: "Häufigkeit",
    phrases: "Phrasen",
    begin: "beginnen",
    feel: "fühlen",
    natural: "natürlich",
    translator: "Übersetzer",
    makes: "macht",
    learning: "Lernen",
    possible: "möglich",
    built: "eingebaut",
    runs: "läuft",
    computer: "Computer",
    private: "privat",
    fast: "schnell",
    replace: "ersetzen",
    selected: "ausgewählte",
    search: "Suche",
    engine: "Engine",
    results: "Ergebnisse",
    reveals: "enthüllt",
    english: "Englisch",
    original: "Original",
    gentle: "sanfte",
    routine: "Routine",
    busy: "beschäftigte",
    people: "Menschen",
    another: "eine andere",
    language: "Sprache",
    minutes: "Minuten",
    curious: "neugieriges",
    hovering: "Darüberfahren",
    during: "während",
    normal: "normalen",
    session: "Sitzung",
    teach: "lehren",
    durable: "dauerhafte",
    isolated: "isolierte",
    consistency: "Beständigkeit",
    beats: "schlägt",
    intensity: "Intensität",
    goal: "Ziel",
    comfortable: "bequem",
    recall: "Erinnern",
    marked: "markierte",
    fonts: "Schriftarten",
    notice: "bemerken",
    distinct: "deutliche",
    italic: "kursiv",
    typeface: "Schrift",
    signals: "signalisiert",
    transformed: "verwandelt",
    extension: "Erweiterung",
    visual: "visuell",
    trains: "trainiert",
    pause: "pausieren",
    guess: "raten",
    check: "prüfen",
    tooltip: "Tooltip",
    need: "brauchen",
  },
  it: {
    immersion: "immersione",
    everyday: "quotidiana",
    reading: "lettura",
    practice: "pratica",
    familiar: "familiari",
    pages: "pagine",
    foreign: "straniere",
    words: "parole",
    mixed: "miste",
    helps: "aiuta",
    brain: "cervello",
    attach: "collegare",
    meaning: "significato",
    vocabulary: "vocabolario",
    without: "senza",
    flashcards: "schede",
    slowly: "lentamente",
    hover: "passa sopra",
    hints: "indizi",
    raise: "aumenta",
    frequency: "frequenza",
    phrases: "frasi",
    begin: "iniziano",
    feel: "sembrare",
    natural: "naturali",
    translator: "traduttore",
    makes: "rende",
    learning: "apprendimento",
    possible: "possibile",
    built: "integrata",
    runs: "funziona",
    computer: "computer",
    private: "privato",
    fast: "veloce",
    replace: "sostituire",
    selected: "selezionate",
    search: "ricerca",
    engine: "motore",
    results: "risultati",
    reveals: "rivela",
    english: "inglese",
    original: "originale",
    gentle: "dolce",
    routine: "routine",
    busy: "impegnate",
    people: "persone",
    another: "un'altra",
    language: "lingua",
    minutes: "minuti",
    curious: "curioso",
    hovering: "passaggio",
    during: "durante",
    normal: "normale",
    session: "sessione",
    teach: "insegnare",
    durable: "durevoli",
    isolated: "isolate",
    consistency: "costanza",
    beats: "batte",
    intensity: "intensità",
    goal: "obiettivo",
    comfortable: "comodo",
    recall: "ricordo",
    marked: "contrassegnati",
    fonts: "caratteri",
    notice: "notare",
    distinct: "distinto",
    italic: "corsivo",
    typeface: "carattere",
    signals: "segnala",
    transformed: "trasformata",
    extension: "estensione",
    visual: "visivo",
    trains: "allena",
    pause: "fermarsi",
    guess: "indovinare",
    check: "controllare",
    tooltip: "suggerimento",
    need: "servono",
  },
  ja: {
    immersion: "没入",
    everyday: "日常の",
    reading: "読書",
    practice: "練習",
    familiar: "見慣れた",
    pages: "ページ",
    foreign: "外国の",
    words: "単語",
    mixed: "混ざった",
    helps: "助ける",
    brain: "脳",
    attach: "結びつける",
    meaning: "意味",
    vocabulary: "語彙",
    without: "なしで",
    flashcards: "単語カード",
    slowly: "ゆっくり",
    hover: "ホバー",
    hints: "ヒント",
    raise: "上げる",
    frequency: "頻度",
    phrases: "フレーズ",
    begin: "始まる",
    feel: "感じる",
    natural: "自然な",
    translator: "翻訳",
    makes: "可能にする",
    learning: "学習",
    possible: "可能",
    built: "内蔵",
    runs: "動く",
    computer: "パソコン",
    private: "非公開",
    fast: "速い",
    replace: "置き換える",
    selected: "選ばれた",
    search: "検索",
    engine: "エンジン",
    results: "結果",
    reveals: "示す",
    english: "英語",
    original: "原文",
    gentle: "やさしい",
    routine: "習慣",
    busy: "忙しい",
    people: "人々",
    another: "別の",
    language: "言語",
    minutes: "分",
    curious: "好奇心のある",
    hovering: "ホバー",
    during: "の間に",
    normal: "普通の",
    session: "セッション",
    teach: "教える",
    durable: "定着する",
    isolated: "孤立した",
    consistency: "継続",
    beats: "勝る",
    intensity: "強度",
    goal: "目標",
    comfortable: "楽な",
    recall: "想起",
    marked: "印の付いた",
    fonts: "フォント",
    notice: "気づく",
    distinct: "独特の",
    italic: "斜体",
    typeface: "書体",
    signals: "示す",
    transformed: "変換された",
    extension: "拡張機能",
    visual: "視覚的な",
    trains: "鍛える",
    pause: "止まる",
    guess: "推測する",
    check: "確認する",
    tooltip: "ツールチップ",
    need: "必要",
  },
};

const SKIP = new Set(
  "a an the and or but if as at by for from in into of on onto to with is are was were be been being am do does did have has had will would can could should may might must not no so that this these those it its he she they them their we us our you your i me my what which who when where why how".split(
    " "
  )
);

const ORIGINAL_HTML = document.getElementById("results").innerHTML;

function hashString(value) {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function ensureTooltip() {
  let tip = document.getElementById("ww-tooltip");
  if (tip) return tip;
  tip = document.createElement("div");
  tip.id = "ww-tooltip";
  tip.innerHTML =
    '<span class="ww-tip-label">English</span><span class="ww-tip-text"></span>';
  document.body.appendChild(tip);
  return tip;
}

function showTooltip(target) {
  const tip = ensureTooltip();
  tip.querySelector(".ww-tip-text").textContent =
    target.getAttribute("data-ww-original") || "";
  const rect = target.getBoundingClientRect();
  tip.classList.add("ww-visible");
  requestAnimationFrame(() => {
    const height = tip.offsetHeight || 48;
    const width = Math.min(280, tip.offsetWidth || 180);
    let left = rect.left + rect.width / 2 - width / 2;
    left = Math.max(12, Math.min(left, window.innerWidth - width - 12));
    let top = rect.top - height - 10;
    if (top < 8) top = rect.bottom + 10;
    tip.style.left = `${left}px`;
    tip.style.top = `${top}px`;
  });
}

function hideTooltip() {
  document.getElementById("ww-tooltip")?.classList.remove("ww-visible");
}

function mark(original, translated, cls) {
  const el = document.createElement("span");
  el.className = cls;
  el.setAttribute("data-ww-original", original);
  el.setAttribute("tabindex", "0");
  el.textContent = translated;
  el.addEventListener("mouseenter", () => showTooltip(el));
  el.addEventListener("mouseleave", hideTooltip);
  el.addEventListener("focus", () => showTooltip(el));
  el.addEventListener("blur", hideTooltip);
  return el;
}

function translateToken(token, lang) {
  const dict = DICTIONARIES[lang] || {};
  return dict[token.toLowerCase()] || null;
}

function transformWords(root, lang, rate) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);

  let index = 0;
  for (const node of nodes) {
    if (!node.parentElement || node.parentElement.closest("a, .url")) continue;
    const parts = node.nodeValue.match(/(\p{L}[\p{L}'’-]*|\s+|[^ \t\n\r\p{L}]+)/gu);
    if (!parts) continue;
    const frag = document.createDocumentFragment();
    let changed = false;
    for (const part of parts) {
      const isWord = /^\p{L}/u.test(part);
      if (!isWord) {
        frag.appendChild(document.createTextNode(part));
        continue;
      }
      const lower = part.toLowerCase();
      const pick =
        part.length > 2 &&
        !SKIP.has(lower) &&
        hashString(`${lower}::${index}`) % 1000 < rate * 1000;
      index += 1;
      const translated = pick ? translateToken(part, lang) : null;
      if (!translated) {
        frag.appendChild(document.createTextNode(part));
        continue;
      }
      frag.appendChild(mark(part, translated, "ww-word"));
      changed = true;
    }
    if (changed) node.parentNode.replaceChild(frag, node);
  }
}

function transformSentences(root, lang) {
  const snippets = root.querySelectorAll(".snippet");
  let counter = 0;
  for (const snippet of snippets) {
    const text = snippet.textContent;
    const sentences = text.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [text];
    snippet.textContent = "";
    for (const sentence of sentences) {
      const trimmed = sentence.trim();
      const should = trimmed.length > 20 && counter % 3 === 1;
      counter += 1;
      if (!should) {
        snippet.appendChild(document.createTextNode(sentence));
        continue;
      }
      const words = trimmed.split(/\s+/);
      const translated = words
        .map((w) => {
          const clean = w.replace(/[^\p{L}'’-]/gu, "");
          const hit = translateToken(clean, lang);
          return hit ? w.replace(clean, hit) : w;
        })
        .join(" ");
      const leading = sentence.match(/^\s*/)?.[0] || "";
      const trailing = sentence.match(/\s*$/)?.[0] || "";
      if (leading) snippet.appendChild(document.createTextNode(leading));
      snippet.appendChild(mark(trimmed, translated, "ww-sentence"));
      if (trailing) snippet.appendChild(document.createTextNode(trailing));
    }
  }
}

function cast() {
  const results = document.getElementById("results");
  results.innerHTML = ORIGINAL_HTML;
  const lang = document.getElementById("demo-language").value;
  const mode = document.getElementById("demo-frequency").value;
  if (mode === "sentences") {
    transformSentences(results, lang);
  } else {
    const rate = mode === "rare" ? 0.08 : 0.28;
    transformWords(results, lang, rate);
  }
  const count = results.querySelectorAll(".ww-word, .ww-sentence").length;
  document.getElementById("demo-status").textContent =
    `Demo dictionary swapped ${count} item(s). Hover a marked word to see English. In Chrome, the real extension uses the Translator API instead.`;
}

document.getElementById("demo-rerun").addEventListener("click", cast);
document.getElementById("demo-frequency").addEventListener("change", cast);
document.getElementById("demo-language").addEventListener("change", cast);
cast();
